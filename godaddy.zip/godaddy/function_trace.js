// function x(){
//     var p=400;
//     function y(){
//         var x=100;
//         console.log(x);
//         console.log(p);
//         function z(){
//             // let p=300;
//             function x1(){
//                 var c=200;
//                 console.log(p);
//                 // console.log(.p);
//             }x1()
//         }z()
//     }y()
//     console.log(p);
// }x()
// // console.log(p);