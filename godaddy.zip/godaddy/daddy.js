// mouseover and mouseout for help & blog





function under(){
    let a=document.getElementById("hov1");
    a.style.textDecoration="underline";

}
function h_out1(){
    let a=document.getElementById("hov1");
    a.style.textDecoration="none"
}
function under1(){
    let a1=document.getElementById("hov");
    a1.style.textDecoration="underline";

}
function h_out(){
    let a=document.getElementById("hov");
    a.style.textDecoration="none"
}
// dropdown 
let d=document.querySelector(".dropdown");
document.body.addEventListener("click",()=>{
    if(d.classList.contains('drop1'))
    {
        d.classList.toggle("drop1");
    }
})

document.querySelector(".button").addEventListener("click",(e)=>{
    e.stopPropagation();
    d.classList.toggle("drop1");

})
// signIn dropdown

let v=document.querySelector(".sign");
document.body.addEventListener("click",()=>{
    if(v.classList.contains("sign1"))
    {
        v.classList.toggle("sign1");
    }
})

document.querySelector(".button1").addEventListener("click",(r)=>{
    r.stopPropagation();
    v.classList.toggle("sign1");
    
})


